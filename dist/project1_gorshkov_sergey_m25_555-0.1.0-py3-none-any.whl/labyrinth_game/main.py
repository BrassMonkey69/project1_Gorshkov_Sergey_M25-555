#!/usr/bin/env python3
print ("Первая попытка запустить проект!")